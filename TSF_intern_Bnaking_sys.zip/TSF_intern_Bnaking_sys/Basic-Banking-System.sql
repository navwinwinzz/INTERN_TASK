SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `banking_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `mini_statement`
--

CREATE TABLE `mini_statement` (
  `sender` varchar(50) NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `amount` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mini_statement`
--

INSERT INTO `mini_statement` (`sender`, `receiver`, `amount`) VALUES
('Boopathi', 'adnaan', 1400),
('kruthik', 'soundar', 1250),
('Hritick', 'kevinson', 1500),
('adnaan', 'Winzz', 1400),
('soundar', 'Boopathi', 1130),
('Thalapathy', 'abinesh', 1250);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `amount` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `email`, `amount`) VALUES
('adnaan', 'adnaan@gmail.com', 25000),
('Winzz', 'winzz@gmail.com', 23500),
('Boopathi', 'boopathi@gmail.com', 10000),
('kruthik', 'kruthik@gmail.com', 33950),
('soundar', 'soundar@gmail.com', 32000),
('Hritick', 'hritick@gmail.com', 31500),
('Thalapthy', 'thalapathy@gmail.com', 31000),
('abinesh', 'abinesh@gmail.com', 21050),
('srinath', 'srinath@gmail.com', 23800),
('kevinson', 'kevinson@gmail.com', 21800);
COMMIT;
